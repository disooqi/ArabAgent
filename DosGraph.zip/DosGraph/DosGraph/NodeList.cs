using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace DosGraph
{
    /// <summary>
    /// Represents a collection of Node&lt;T&gt; instances.
    /// </summary>
    /// <typeparam name="T">The type of data held in the Node instances referenced by this class.</typeparam>


    public class NodeList<T> : List<Node<T>>
    {
        #region Constructors
        public NodeList() : base() { }

        public NodeList(int initialSize)
        {
            // Add the specified number of items
            for (int i = 0; i < initialSize; i++)
                base.Add(default(Node<T>));
        }
        #endregion

            #region Methods
        /// <summary>
        /// Searches the NodeList for a Node containing a particular value.
        /// </summary>
        /// <param name="value">The value to search for.</param>
        /// <returns>The Node in the NodeList, if it exists; null otherwise.</returns>

            public Node<T> FindByValue(T value)
            {
                // search the list for the value
                Enumerator list = base.GetEnumerator();
                while(list.MoveNext())
                {
                    if (list.Current.Value.Equals(value))
                        return list.Current;
                }

                // if we reached here, we didn't find a matching node
                return null;
            }
            #endregion
    }

}
