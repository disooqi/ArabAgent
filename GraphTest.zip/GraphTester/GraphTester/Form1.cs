using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DosGraph;

namespace GraphTester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graph<int> fs = new Graph<int>();
            fs.AddNode(30);
            fs.AddNode(22);
            fs.AddNode(1);
            fs.AddNode(7);
            MessageBox.Show(fs.Count.ToString());
            fs.AddUndirectedEdge(22, 1, 230);
            fs.AddUndirectedEdge(22, 15, 230);

        }
    }
}