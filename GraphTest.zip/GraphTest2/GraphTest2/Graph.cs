using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace GraphTest2
{
    class Graph
    {
        List<Node> vertices;
        int _edgeCount;

        public Graph() { vertices = new List<Node>(); }

        public void addNode(string nKey)
        {
            vertices.Add(new Node(nKey));
        }

        public void addNode(string nKey, double importance)
        {
            vertices.Add(new Node(nKey, importance));
        }

        public void addNode(string nKey, double importance, int docFreq)
        {
            vertices.Add(new Node(nKey, importance,docFreq));
        }

        public void addEdge(string fromKey, string toKey)
        {
            int fromIndex, toIndex;
            if ((fromIndex = nodeIndex(fromKey)) != -1 && (toIndex = nodeIndex(toKey)) != -1)
            {
                if (!vertices[fromIndex].isNeighbour(toKey) && !vertices[toIndex].isNeighbour(fromKey))
                {
                    vertices[fromIndex].AddNewNeigbour(toKey);
                    vertices[toIndex].AddNewNeigbour(fromKey);
                }
            }
        }

        public void addEdge(string fromKey, string toKey, double edgeImportance)
        {
            int fromIndex, toIndex;
            if (fromKey.Equals(toKey))
                return;
            if ((fromIndex = nodeIndex(fromKey)) != -1 && (toIndex = nodeIndex(toKey)) != -1)
            {
                if (!vertices[fromIndex].isNeighbour(toKey) && !vertices[toIndex].isNeighbour(fromKey))
                {
                    vertices[fromIndex].AddNewNeigbour(toKey,edgeImportance);

                    vertices[toIndex].AddNewNeigbour(fromKey, edgeImportance);
                    _edgeCount++;
                }
            }
        }

        public int verticsCount
        {
            get { return vertices.Count; }
        }

        public int edgeCount
        {
            get { return -1; }
        }

        //private bool nodeExisted(int nKey)
        //{
            
        //    IEnumerator<Node> IEver = vertices.GetEnumerator();
        //    while (IEver.MoveNext())
        //        if (nKey.Equals(IEver.Current.NodeKey))
        //            return true;
                        
        //    return false; // reaching here means the node is not exist in the graph.
        //}

        private bool nodeExisted(string nKey)
        {
            if (nodeIndex(nKey) == -1)
                return false;
            else return true;
        }

        private int nodeIndex(string nKey)
        {
            for (int i = 0; i < vertices.Count; i++)
            {
                if (vertices[i].NodeKey.Equals(nKey))
                    return i;
            }
            return -1;
        }

        public Node getNodeWithValue(string nkey)
        {
            IEnumerator<Node> IEver = vertices.GetEnumerator();
            while (IEver.MoveNext())
                if (nkey.Equals(IEver.Current.NodeKey))
                    return IEver.Current;

            return null; // reaching here means the node is not exist in the graph.
        }

        public List<Node> NodesList
        {
            get { return vertices; }
        }
    }
}
