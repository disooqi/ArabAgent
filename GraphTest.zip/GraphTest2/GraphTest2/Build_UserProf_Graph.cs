using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace GraphTest2
{
    public class Build_UserProf_Graph
    {
        // read from xml file 
        //then, convert the xml file into graph by calculating the importance of both nodes and edges
        public void constructGraphFromUserProfile(string path)
        {
            Graph profileGraph = new Graph();

            string pth = @"F:\SWProjects\MasterSW\profile_creation\profile\SemanticNetwork.xml";

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(pth);
            //UPDATE Profile Here
            XmlElement rootElem = xmldoc.DocumentElement;
            XmlNodeList nodeElements = rootElem.GetElementsByTagName("C");
            for (int i = 0; i < nodeElements.Count; i++)
            {
                IEnumerator daysEnum = nodeElements[i].FirstChild.GetEnumerator();
                double conceptWeight = 0;
                int docFreq = 0;
                while (daysEnum.MoveNext())
                {
                    conceptWeight += calculateDayImportance(((XmlNode)daysEnum.Current).Attributes[0].Value) *
                        double.Parse(((XmlNode)daysEnum.Current).Attributes[2].Value);

                    docFreq += int.Parse(((XmlNode)daysEnum.Current).Attributes[1].Value);
                }

                profileGraph.addNode(nodeElements[i].Attributes[0].Value, conceptWeight, docFreq);
            }

            XmlNodeList edgeElements = rootElem.GetElementsByTagName("E");
            for (int i = 0; i < edgeElements.Count; i++)
            {
                string fromNodeKey = edgeElements[i].Attributes[0].Value;
                string toNodeKey   = edgeElements[i].Attributes[1].Value;

                IEnumerator daysEnum = edgeElements[i].FirstChild.GetEnumerator();
                double edgeWeight = 0;
                int edgeDocFreq = 0;

                while (daysEnum.MoveNext())
                {

                    edgeWeight += calculateDayImportance(((XmlNode)daysEnum.Current).Attributes[0].Value) *
                        (double.Parse(((XmlNode)daysEnum.Current).Attributes[2].Value)/1);
                    edgeDocFreq += int.Parse(((XmlNode)daysEnum.Current).Attributes[1].Value);
                }
                edgeWeight = (double)edgeDocFreq/(profileGraph.getNodeWithValue(fromNodeKey).DocFreq + profileGraph.getNodeWithValue(toNodeKey).DocFreq - edgeDocFreq);
                profileGraph.addEdge(fromNodeKey, toNodeKey, edgeWeight);
            }
        }
        private double calculateConceptImportance()
        { return 0; }
        private double calculateDayImportance(string dateStr)
        {
            DateTime date = DateTime.Parse(dateStr);
            TimeSpan dayDif = DateTime.Today - date;
            if (dayDif.TotalDays > 30)
                return 0;
            else return (30 - dayDif.TotalDays) / 30;
        }
    }
}
