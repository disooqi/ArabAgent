using System;
using System.Collections.Generic;
using System.Text;

namespace profileBuildingTester
{
    class userCollection
    {
        string _userCollectionPath;
        public userCollection(string path) { _userCollectionPath = path; }


    }
}
