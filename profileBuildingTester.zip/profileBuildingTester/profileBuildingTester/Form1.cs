using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web;
using ArabAgent;
using nsText_Analysis;
using System.IO;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using nsPhrase_Detection;
using dosDataStructure;
//using System.Windows.Browser;

namespace profileBuildingTester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < 30; i++)
                createProfile(1);
        }

        private void createProfile(int noOfDays)
        {
            string dirsPath = @"F:\SWProjects\MasterSW\user documents\30 DAYS\";
            string[] collectionDirectories ={ "0001", "0002", "0003", "0004", "0005", "0006", "0007", "0008", "0009",
                    "0010", "0011", "0012", "0013", "0014", "0015", "0016", "0017", "0018","0019","0020","0021","0022",
                    "0023","0024","0025","0026","0027","0028","0029", "0030"};

            //DateTime curDate = DateTime.Parse("9/05/2011");
            ArabAgent_Class agent;
            List<ArabAgent_Class> agents = new List<ArabAgent_Class>();

            for (int i = 0; i < noOfDays; i++)
            {
                int userName = i + 1;
                agents.Add(new ArabAgent_Class(userName.ToString()));

                //curDate = curDate.AddDays(1);
                //sysTime.modificaHoraSistema(curDate);

                string[] dayfiles = Directory.GetFiles(dirsPath + collectionDirectories[i]);

                for (int j = 0; j < dayfiles.Length; j++)
                {
                    StreamReader sr = File.OpenText(dayfiles[j]);
                    string fileTxt = sr.ReadToEnd();
                  
                    Match title = Regex.Match(fileTxt, "<title>.*</title>", RegexOptions.Singleline);
                    Match body = Regex.Match(fileTxt, "<body>.*</body>", RegexOptions.Singleline);

                    string titleStr = title.Value.Replace("<title>", "").Replace("</title>", "");
                    string bodyStr = body.Value.Replace("<body>", "").Replace("</body>", "");

                    sr.Close();

                    //detect the concepts and their occurrence frequency
                    //Dictionary<int, n_gram> pos_struct_dic = new Dictionary<int, n_gram>();
                    //PhrasesDetector PD_Obj = new PhrasesDetector();
                    //PD_Obj.wikify(titleStr + " " + bodyStr, ref pos_struct_dic);

                    //for (int k = 0; k < agents.Count; k++)
                        agents[k].updateAgent(ref pos_struct_dic);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

    public class sysTime
    {
        [DllImport("Kernel32.dll")]
        public static extern bool SetLocalTime(ref SYSTEMTIME Time);

        // The structure needs to be spelt out in full, even though
        // we will only be using wYear
        public struct SYSTEMTIME
        {
            public ushort wYear;
            public ushort wMonth;
            public ushort wDayOfWeek;
            public ushort wDay;
            public ushort wHour;
            public ushort wMinute;
            public ushort wSecond;
            public ushort wMilliseconds;

            public void FromDateTime(DateTime time)
            {
                wYear = (ushort)time.Year;
                wMonth = (ushort)time.Month;
                wDayOfWeek = (ushort)time.DayOfWeek;
                wDay = (ushort)time.Day;
                wHour = (ushort)time.Hour;
                wMinute = (ushort)time.Minute;
                wSecond = (ushort)time.Second;
                wMilliseconds = (ushort)time.Millisecond;
            }
        }

        public static bool modificaHoraSistema(DateTime _novaHora)
        {
            try
            {
                SYSTEMTIME st = new SYSTEMTIME();
                st.FromDateTime(_novaHora);
                SetLocalTime(ref st);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }


}