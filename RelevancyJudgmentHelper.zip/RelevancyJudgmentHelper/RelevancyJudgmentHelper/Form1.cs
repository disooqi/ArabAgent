using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;

namespace RelevancyJudgmentHelper
{
    public partial class Form1 : Form
    {
        string[] newsArticles;
        static int i = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            nextArticle();
        }

        private void nextArticle()
        {
            newsArticles = Directory.GetFiles(@"F:\SWProjects\MasterSW\user documents\REST\all\9-6-2011");

            //newsArticles
            using (StreamReader sr = new StreamReader(newsArticles[i++], Encoding.UTF8))
            {
                string docStr = sr.ReadToEnd();

                int titleStart = docStr.IndexOf("<title>") + 7;
                int titleLength = docStr.IndexOf("</title>") - docStr.IndexOf("<title>") - 7;

                textBox1.Text = docStr.Substring(titleStart, titleLength);

                int bodyStart = docStr.IndexOf("<body>") + 6;
                int bodyLength = docStr.IndexOf("</body>") - docStr.IndexOf("<body>") - 6;
                textBox2.Text = docStr.Substring(bodyStart, bodyLength);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked)
            {
                using (StreamWriter sw = new StreamWriter(@"F:\SWProjects\MasterSW\user documents\REST\relevancy_judgement.txt", true, Encoding.UTF8))
                {
                    sw.WriteLine(Path.GetFileNameWithoutExtension(newsArticles[i-1])+";1");
                }
                nextArticle();
            }
            else if (radioButton2.Checked)
            {
                using (StreamWriter sw = new StreamWriter(@"F:\SWProjects\MasterSW\user documents\REST\relevancy_judgement.txt", true, Encoding.UTF8))
                {
                    sw.WriteLine(Path.GetFileNameWithoutExtension(newsArticles[i - 1]) + ";0");
                }
                nextArticle();
            }
            else { MessageBox.Show("��� ��� ���� �� ��� ���"); }
        }
    }
}