using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ArabAgent;

namespace ArabAgentEvaluator
{
    public partial class Form1 : Form
    {
        string profilePath;
        string profiles1 = @"F:\SWProjects\MasterSW\ArabAgent\ArabAgent\titles_only\";
        string profiles2 = @"F:\SWProjects\MasterSW\ArabAgent\ArabAgent\title_body1\";
        string dayUsedInEval = @"F:\SWProjects\MasterSW\user documents\REST\all\9-6-2011";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
                return;
            FileInfo profileFI = new FileInfo(profilePath);
            ArabAgent_Class myAgent = new ArabAgent_Class(profileFI);
            string[] files = Directory.GetFiles(dayUsedInEval);
            DataTable dTable = new DataTable();
            DataRow dRow = null;

            dTable.Columns.Add("IsChecked", System.Type.GetType("System.Boolean"));
            dTable.Columns.Add("Title");
            dTable.Columns.Add("Weight");


            for (int i = 0; i < files.Length; i++)
            {
                using (StreamReader sr = new StreamReader(files[i], Encoding.UTF8))
                {
                    dRow = dTable.NewRow();

                    string fileTxt = sr.ReadToEnd();

                    Match title = Regex.Match(fileTxt, "<title>.*</title>", RegexOptions.Singleline);
                    Match body = Regex.Match(fileTxt, "<body>.*</body>", RegexOptions.Singleline);

                    string titleStr = title.Value.Replace("<title>", "").Replace("</title>", "");
                    string bodyStr = body.Value.Replace("<body>", "").Replace("</body>", "");

                    dRow["Title"] = titleStr;
                    dRow["Weight"] = myAgent.calculateInterestingValue(titleStr + " " + bodyStr);
                    dTable.Rows.Add(dRow);
                    dTable.AcceptChanges();
                }

                dataGridView1.DataSource = dTable;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                int NoOfDays = comboBox1.SelectedIndex + 1;
                profilePath = profiles1 + NoOfDays.ToString() + ".xml";
            }
            else if (radioButton2.Checked)
            {
                int NoOfDays = comboBox1.SelectedIndex + 1;
                profilePath = profiles2 + NoOfDays.ToString() + ".xml";
            }
            //MessageBox.Show(comboBox1.SelectedIndex.ToString());
            //DateTime not_before = DateTime.Parse("11/05/2011");
            //not_before = not_before.AddDays(comboBox1.SelectedIndex);
            
        }
    }
}